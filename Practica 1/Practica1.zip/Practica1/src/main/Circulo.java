package main;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//Realiza por Arturo Requejo Portilla para la Practica 1

public class Circulo {
	
	public double radio;
	
	public Circulo(double radio) {
		radio = this.radio;
	}
	
	public  double area(double radio) {
		double area;
		area = Math.PI * Math.pow(radio, 2);
		return area;
	}
	
	

}
