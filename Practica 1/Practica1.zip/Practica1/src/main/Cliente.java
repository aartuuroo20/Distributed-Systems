package main;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//Realiza por Arturo Requejo Portilla para la Practica 1


public class Cliente {

	public static void main(String[] args) {
		final String HOST = "127.0.0.1";
		final int PUERTO = 5001;
		DataInputStream in;
		DataOutputStream out;
		final double radio = 4; //Inicializamos una variable con el radio 
				
		try {
			Socket sc = new Socket(HOST, PUERTO);
			in = new DataInputStream(sc.getInputStream());
			out = new DataOutputStream(sc.getOutputStream());
			
			System.out.println("El radio es: " + radio); //Imprimimos el radio en el cliente
			out.writeDouble(radio); //Enviamos el radio para que el servidor calcule el area
			double mensaje = in.readDouble(); //Recibimos el area calculado por parte del servidor
			System.out.println("El area es: " + mensaje); //Imprimimos por pantalla el area
			sc.close();
		}catch(IOException ex) {
			Logger.getLogger(Servidor.class.getCanonicalName()).log(Level.SEVERE, null, ex);
		}
	}
}
