package main;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;

//Realiza por Arturo Requejo Portilla para la Practica 1


public class Servidor {
	public static void main(String[] args) {
        ServerSocket servidor = null;
        Socket sc = null;
        DataInputStream in;
        DataOutputStream out;
        final int PUERTO = 5001;
        
        try {
            servidor = new ServerSocket (PUERTO);
            System.out.println("Servidor iniciado");
            
            while(true) {
                sc = servidor.accept();
                System.out.println("Cliente conectado");
                
                in = new DataInputStream(sc.getInputStream());
                out = new DataOutputStream(sc.getOutputStream());
                
                double mensaje = in.readDouble(); //Recibimos el mensaje enviado por el cliente
                System.out.println("El radio con el que calcularemos el area es: " + mensaje);
                Circulo circulo = new Circulo(mensaje); //Creamos el objeto circulo 
                double area = circulo.area(mensaje); //Con el mensaje recibido calculamos el area llamando al objeto ciruclo con la funcion area pansando el mensaje
                System.out.println("El resultado mandado es: " + area); //Imprimimos el area calculada en el servidor
                out.writeDouble(area); //Enviamos el area calculada al cliente
                
                sc.close();
                System.out.println("Cliente desconectado");
            }
        } catch(IOException ex) {
            Logger.getLogger(Servidor.class.getCanonicalName()).log(Level.SEVERE, null, ex);
        }
    }
}