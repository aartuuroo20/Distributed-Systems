/**
 * 
 */
/**
 * @author aartuuroo20
 *
 */
module Practica1 {
	requires java.logging;
}