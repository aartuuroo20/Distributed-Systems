export type Message = {
  user: string;
  message: string;
};
