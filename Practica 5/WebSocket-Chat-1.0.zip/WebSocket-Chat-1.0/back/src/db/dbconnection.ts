import { Message } from "../types";

export const messages: Message[] = [];
